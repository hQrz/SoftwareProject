package com.zsh.ricky.test.util;

/**
 * Created by Ricky on 2017/10/23.
 */

public class UrlResources {

    public static final String ADD_HISTORY = "add_history";
    public static final String HISTORY = "history";
    public static final String DELETE_HISTORY = "delete_history";
}
